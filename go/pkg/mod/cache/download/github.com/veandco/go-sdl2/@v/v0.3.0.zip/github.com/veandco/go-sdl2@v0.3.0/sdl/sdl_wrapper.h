#if defined(_WIN32)
	#include <SDL2/SDL.h>
	#include <stdlib.h>
#else
	#include <SDL.h>
#endif
